import fs from 'fs'
import path from 'path'
import posthtml from 'posthtml'
import { parser } from 'posthtml-parser'
import { match } from 'posthtml/lib/api'
import expressions from 'posthtml-expressions'
import replaceAliases from './posthtmlReplaceAliases.js'

/**
 * Treatment of attributes of the node with replacement of alias.
 * @param {Object} attrs - The attribute object
 * @param {boolean} prependDot - Do you add a point in front of a value
 * @param {string[]} targetAttrs - Array of attributes to search (eg ['src', 'url'])
 * @returns {string|false} - Found SRC/URL or False value
 */
const processAttributes = (attrs, prependDot, targetAttrs) => {
	let src = false
	for (const [attr, value] of Object.entries(attrs || {})) {
		if (typeof value === 'string') {
			attrs[attr] = replaceAliases(value, { prependDot })
			if (targetAttrs.includes(attr)) src = attrs[attr]
		}
	}
	return src
}

/**
 * Tag processing <INCLUDE> and replacement of alias in attributes.
 * @param {Object} options
 * @param {string} options.root
 * @param {Object} options.posthtmlExpressionsOptions
 * @returns {Function}
 */
export default (options = {}) => {
	const { root = './', encoding = 'utf-8', posthtmlExpressionsOptions = { locals: false } } = options
	const tagsArr = ['include', 'fetch']
	const attrArr = ['src', 'url']

	return function posthtmlInclude(tree) {
		tree.parser = tree.parser || parser
		tree.match = tree.match || match

		tagsArr.forEach((tag) => {
			tree.match({ tag }, (node) => {
				let src = node.attrs?.src || node.attrs?.url || false
				const exprOptions = { ...posthtmlExpressionsOptions, ...(options.delimiters && { delimiters: options.delimiters }) }

				if (node.attrs) {
					src = processAttributes(node.attrs, true, attrArr)
				}

				if (tag === 'include' && src) {
					const filePath = path.resolve(root, src)
					let source = fs.readFileSync(filePath, encoding)

					try {
						const localsRaw = node.attrs.locals || (node.content ? node.content.join('').replace(/\n/g, '') : false)
						if (localsRaw) {
							const localsJson = JSON.parse(localsRaw)
							exprOptions.locals = exprOptions.locals ? { ...exprOptions.locals, ...localsJson } : localsJson
						}
					} catch { }

					if (exprOptions.locals) {
						source = posthtml().use(expressions(exprOptions)).process(source, { sync: true }).html
					}

					const subtree = tree.parser(source)
					Object.assign(subtree, { match: tree.match, parser: tree.parser, messages: tree.messages })
					const content = source.includes('include') ? posthtmlInclude(subtree) : subtree

					tree.messages.push({ type: 'dependency', file: filePath })

					return { tag: false, content }
				}

				return node
			})
		})

		tree.match({ attrs: true }, (node) => {
			if (!tagsArr.includes(node.tag) && node.attrs) {
				processAttributes(node.attrs, false, [])
			}
			return node
		})

		return tree
	}
}