/**
* Universal function to replace alias in rows, objects or arrays.
 * @param {string | object | Array} data - Processing data (row, object or array).
 * @param {Object} options - Replacement options.
 * @param {boolean} [options.prependDot=false] - Or add a point ('.') At the beginning of the way.
 * @param {boolean} [options.normalizePath=true] - Or normalize the path (remove double slash).
 * @param {boolean} [options.sortAliases=true] - Or sort allias in length (longer first).
 * @param {boolean} [options.preserveOriginal=true] - Whether to return the original data if there are no alias.
 * @param {Function} [options.transformReplacement] - A function for transformation of replacement value.
 * @returns {string | object | Array} - Produced data with replaced alias.
 */
import templateCfg from '../../template.config.js'

const replaceAliases = (data, { prependDot = false, normalizePath = true, sortAliases = true, preserveOriginal = true, transformReplacement } = {}) => {
	const aliases = templateCfg.aliases || {}

	// If Alias ​​are not and Preserveoriginal is on, return the original data
	if (preserveOriginal && Object.keys(aliases).length === 0) {
		return data
	}

	// Function to screening special characters in regular expressions
	const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

	// Line processing
	if (typeof data === 'string') {
		let result = data
		// Sort allias by length (longer first) if sortaliases are on
		const sortedAliases = sortAliases
			? Object.keys(aliases).sort((a, b) => b.length - a.length)
			: Object.keys(aliases)

		sortedAliases.forEach((alias) => {
			const regex = new RegExp(escapeRegExp(alias), 'g')
			if (result.match(regex)) {
				let replacement = aliases[alias]
				// Add a dot if required
				if (prependDot) {
					replacement = `.${replacement}`
				}
				// We apply custom transformation if transmitted
				if (typeof transformReplacement === 'function') {
					replacement = transformReplacement(replacement, alias)
				}
				result = result.replace(regex, replacement)
			}
		})
		// Normalize the path if required
		if (normalizePath) {
			result = result.replace(/\/+/g, '/')
		}
		return result
	}

	// Treatment of arrays
	if (Array.isArray(data)) {
		return data.map(item => replaceAliases(item, { prependDot, normalizePath, sortAliases, preserveOriginal, transformReplacement }))
	}

	// Object processing
	if (data && typeof data === 'object') {
		return Object.fromEntries(
			Object.entries(data).map(([key, value]) => [
				key,
				replaceAliases(value, { prependDot, normalizePath, sortAliases, preserveOriginal, transformReplacement }),
			])
		)
	}

	// We return unchanged data if it is not a line, array or objectт
	return data
}

export default replaceAliases